# Preprocessing scripts for ChromBPNet

The scripts in this folder are pre-processing steps to convert input reads to Bigwig format for trainining ChromBPNet models.

## Requirements

To run these scripts you will need `bedtools`, `samtools` and `bedGraphToBigWig` (from ucsc) tools. These scripts are tested for bulk and single-cell ATAC-seq, and for bulk DNase-seq.

## BAM/fragment file/tagAlign file to Bigwig

We convert input BAMS to appropriately shifted (+4/-4 shift for ATAC and 0/+1 shift for DNASE) Bigwigs consistent with our training pipeline.

```
usage: reads_to_bigwig.py [-h] -g GENOME
                          (-ibam INPUT_BAM_FILE | -ifrag INPUT_FRAGMENT_FILE | -itag INPUT_TAGALIGN_FILE)
                          -c CHROM_SIZES -o OUTPUT_PREFIX -d {ATAC,DNASE} [-p PLUS_SHIFT]
                          [-m MINUS_SHIFT] 

Convert input BAM/fragment/tagAlign file to appropriately shifted unstranded Bigwig

optional arguments:
  -h, --help            show this help message and exit
  -g GENOME, --genome GENOME
                        reference genome fasta file
  -ibam INPUT_BAM_FILE, --input-bam-file INPUT_BAM_FILE
                        Input BAM file
  -ifrag INPUT_FRAGMENT_FILE, --input-fragment-file INPUT_FRAGMENT_FILE
                        Input fragment file
  -itag INPUT_TAGALIGN_FILE, --input-tagalign-file INPUT_TAGALIGN_FILE
                        Input tagAlign file
  -c CHROM_SIZES, --chrom-sizes CHROM_SIZES
                        Chrom sizes file
  -o OUTPUT_PREFIX, --output-prefix OUTPUT_PREFIX
                        Output prefix (path/to/prefix)
  -d {ATAC,DNASE}, --data-type {ATAC,DNASE}
                        assay type
  -p PLUS_SHIFT, --plus-shift PLUS_SHIFT
                        Plus strand shift applied to reads. Estimated if not specified
  -m MINUS_SHIFT, --minus-shift MINUS_SHIFT
                        Minus strand shift applied to reads. Estimated if not specified
```

Please supply one of BAM(`-ibam`)/fragment file(`-ifrag`)/tagAlign file(`-itag`) as input. The script generates an unstranded Bigwig- forward and reverse strands are combined with appropriate shifting (+4/-4 for ATAC and 0/+1 for DNase). Output is stored at `{OUTPUT_PREFIX}_unstranded.bw`. The directory in the prefix, if applicable, must already exist.

If supplying a fragment file, it should minimally have 3 columns for chr, start and end. Each line must represent a fragment with Tn5 transposition events at both ends.

If supplying a tagAlign file, it should minimally contain 3 columns for chr, start and end, and a 6th column with the strand. 

Both gzipped and plain text files are allowed. Sorting is not expected.

The `CHROM_SIZES` file should be a tab-separated file with two columns. First column is the chromosome and second column is the chromsome length. Make sure the input BAM/fragment/tagAlign file are consistent with the chromosomes in `CHROM_SIZES`.

### Example usage

```bash
python reads_to_bigwig.py -ifrag my_sample.frag.tsv.gz \
                          -g hg38.fa \
                          -c hg38.chrom.sizes \
                          -o /output/directory/my_sample
                          -d ATAC
```

Example usage when we have an input ATAC-seq fragment file `my_sample.frag.tsv.gz`. Output is stored to `/output/directory/my_sample_unstranded.bw`, please ensure the directory `/output/directory/` exists.

### Automatic shift detection

Most ATAC-seq (single-cell and bulk) pipelines shift Tn5 reads by +4/-5 by default. However when combining analyses with other tools, the effective shift can be different than +4/-5 due to off-by-one errors. Our script handles such cases by default by automatically detecting the enzyme shift (for ATAC and DNase) and correcting it appropriately (+4/-4 for ATAC and 0/+1 for DNase) for consistency with the training pipeline.

In rare cases, you may see an error such as "Input file shifts inconsistent" or "Input shift is non-standard". In such cases, if you know the actual shift for your input file (typically +0/+0 for BAMs, and +4/-5 for ATAC fragment/tagAligns) you can supply them using the `--plus-shift` and `--minus-shift` flags. However, if you are uncertain, please reach out to us by submitting an [Issue](https://github.com/kundajelab/chrombpnet/issues).


## Discussion


### Suggestions for preparing input data

Please ensure your input files are filtered for quality metrics and duplicates are removed appropriately. For single-end data, we recommend not removing duplicates. Fragment files obtained from Chromap, cellranger and similar tools are suitable with this pipeline. For single-cell analyses, you may wish to aggregate fragments by cluster instead of sample to train cluster-specific ChromBPNet models.


### Wondering why we are using the  +4/-4 ATAC shift (instead of the popular +4/-5 ATAC shift) and 0/+1 DNASE shift (instead of the popular no shift)? 

Here we show you what a PWM built from unstranded bigwigs look like when considering different shifts. To convert bigwigs to PWM use the scripts provided in the `analysis/` directory. From the below images we see that the signal on forward and revere strand reinforce themselves when we consider +4/-4 shift giving us the Tn5/DNASE-I bias motif PWM that we know of in literature ([Figure 1 in HINT-ATAC][url3] paper).


#### PWM from unstranded ATAC bigwig with no shift

![Image](images/atac_no_shift.png)

#### PWM from  unstranded GM12878 ATAC bigwig with +4/-4 shift on forward/reverse strand respectively 

![Image](images/atac_44_shift.png)

#### PWM from unstranded GM12878 ATAC bigwig with +4/-5 shift on forward/reverse strand respectively

![Image](images/atac_45_shift.png)


#### PWM from unstranded GM12878 DNASE bigwig with no shift 

![Image](images/dnase_no_shift.png)


#### PWM from unstranded GM12878 DNASE bigwig with 0/+1 shift on forward/reverse strand respectively

![Image](images/dnase_01_shift.png)

The images can be reproduced by running the scripts in the `images/directoy`

### What is the intuition behind performing the different filtering step on PE and SE?

When considering paired-end data, duplicates can be marked correctly because we have paired-end reads and hence we can remove them. This is not possible when considering single-end reads and hence we do not remove duplicates (here if we attempt to do this we might be throwing away actual signal information)

[url1]: https://github.com/ENCODE-DCC/atac-seq-pipeline
[url2]: https://broadinstitute.github.io/picard/explain-flags.html
[url3]: https://genomebiology.biomedcentral.com/articles/10.1186/s13059-019-1642-2



